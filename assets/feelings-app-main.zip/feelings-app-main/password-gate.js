/*! Brave Feelings Lab — Password Gate (client-side) */
(() => {
  "use strict";

  const TOKEN_KEY = "bfl_auth_v1";
  const RETURN_KEY = "bfl_return_to_v1";

  function detectBase() {
    const seg = location.pathname.split("/").filter(Boolean)[0] || "";
    return seg === "feelings-app" ? "/feelings-app" : "";
  }

  const BASE = detectBase();

  function currentFile() {
    const p = location.pathname.split("/").filter(Boolean).pop() || "index.html";
    return (p.includes(".") ? p : "index.html").toLowerCase();
  }

  function isPublicPage() {
    const qs = new URLSearchParams(location.search);
    if (qs.has("nogate")) return true;
    return ["login.html", "hash.html", "goodbye.html"].includes(currentFile());
  }

  function isAuthed() {
    try {
      const obj = JSON.parse(localStorage.getItem(TOKEN_KEY));
      return obj && obj.ok && Date.now() < obj.exp;
    } catch {
      return false;
    }
  }

  function requireAuth() {
    if (isPublicPage() || isAuthed()) return;

    const ret = location.pathname + location.search + location.hash;
    sessionStorage.setItem(RETURN_KEY, ret);

    location.replace(location.origin + BASE + "/login.html");
  }

  window.BFLGate = {
    logout() {
      localStorage.removeItem(TOKEN_KEY);
      sessionStorage.removeItem(RETURN_KEY);
      location.replace(location.origin + BASE + "/login.html");
    }
  };

  requireAuth();
})();

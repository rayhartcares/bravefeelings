// BFL_ANGER_UI_V12
// Brave Feelings Lab – Anger (clean, no emotion picker)
// This is a single mini-program that always boots directly into Anger.

(function () {
  const app = document.getElementById("app");

  // Base path helpers (works at root OR inside /feelings-app/)
  const seg1 = window.location.pathname.split("/").filter(Boolean)[0] || "";
  const BASE = seg1 && seg1 !== "emotions" ? `/${seg1}` : ""; // "" OR "/feelings-app"
  const goTo = (path) => (window.location.href = window.location.origin + BASE + path);

  // Top bar buttons
  const btnBack = document.getElementById("btnBack");
  const btnHome = document.getElementById("btnHome");
  const btnExit = document.getElementById("btnExit");
  const btnMusic = document.getElementById("btnMusic");

  const bgMusic = document.getElementById("bgMusic");
  let musicOn = false;

  const history = [];

  const state = {
    view: "welcome",     // welcome | character | trigger | reaction_pick | reaction_result | tools | tool_steps
    character: null,     // "boy" | "girl"
    reactionKey: null,   // key from reactions
    toolKey: null,       // key from tools
    toolStep: 0,
  };

 const reactions = [
  { key:"yell",  title:"Yelling Loudly",   emoji:"🗣️", note:"You yell so loudly that other people cover their ears. Everyone feels tense and upset. The problem is still not solved." },
  { key:"hit",   title:"Hitting",         emoji:"👊", note:"You hit someone or something. Somebody gets hurt. The problem gets bigger and you may get in trouble." },
  { key:"throw", title:"Throwing Things", emoji:"💥", note:"You throw things. Something might break. People feel unsafe and upset." },

  // 4th reaction (you can rename this to whatever your original 4th reaction was)
  { key:"mean",  title:"Saying Mean Words", emoji:"🗯️", note:"You say hurtful words. Feelings get hurt, the problem grows, and it becomes harder to fix things." }
];

  const tools = [
    {
      key: "squeeze",
      title: "Stress Squeeze",
      emoji: "🧸",
      steps: [
        "Grab a soft toy, pillow, or just your own hands. Squeeze them tight.",
        "Hold for 3 seconds… then release slowly.",
        "Repeat 3 times. Notice your body relax a little."
      ]
    },
    {
      key: "balloon",
      title: "Balloon Breathing",
      emoji: "🎈",
      steps: [
        "Breathe in slowly through your nose for 3 seconds.",
        "Hold for 1 second.",
        "Breathe out slowly for 4 seconds, like a balloon letting air out."
      ]
    },
    {
      key: "talk",
      title: "Use Calm Words",
      emoji: "💬",
      steps: [
        "Say what happened in one sentence: “My toy broke.”",
        "Say how you feel: “I feel angry.”",
        "Ask for help: “Can you help me fix it or find another one?”"
      ]
    }
  ];

  // ---------- Rendering helpers ----------
  function setView(nextView) {
    if (state.view !== nextView) history.push(state.view);
    state.view = nextView;
    render();
  }

  function back() {
    const prev = history.pop();
    if (!prev) return;
    state.view = prev;
    render();
  }

  function el(html) {
    const wrap = document.createElement("div");
    wrap.innerHTML = html.trim();
    return wrap.firstElementChild;
  }

  function screenCenter({ kicker, title, subtitle, emoji, buttonsHtml }) {
    return `
      <div class="screen center">
        <div class="kicker">${kicker}</div>
        <div class="h1">${title}</div>
        <div class="sub">${subtitle}</div>
        <div class="emoji">${emoji}</div>
        <div class="btnRow">${buttonsHtml}</div>
      </div>
    `;
  }

  // ---------- Views ----------
  function viewWelcome() {
    return screenCenter({
      kicker: "Brave Feelings Lab",
      title: "Anger",
      subtitle: "Emotion Navigator",
      emoji: "😡",
      buttonsHtml: `<button class="btn btnPrimary" id="startBtn" type="button">Start</button>`
    });
  }

  function viewCharacter() {
    return `
      <div class="screen">
        <div class="panel">
          <p class="cardTitle">Who is playing today?</p>
          <p class="cardSub">Pick the character that looks most like you.</p>

          <div class="grid2">
            <button class="pick pickCard" id="pickBoy" type="button"><span class="pickEmoji">👦</span><span class="pickText">Use Boy</span></button>
            <button class="pick pickCard" id="pickGirl" type="button"><span class="pickEmoji">👧</span><span class="pickText">Use Girl</span></button>
          </div>

          <div class="btnRow">
            <button class="btn" id="backFromCharacter" type="button">Back</button>
          </div>
        </div>
      </div>
    `;
  }

  function viewTrigger() {
    return `
      <div class="screen">
        <div class="panel">
          <p class="cardTitle">Uh oh! Something happened!</p>
          <p class="cardSub">Let’s see why you feel angry.</p>

          <div class="eventRow"><span class="eventEmoji">🧸</span><span class="eventArrow">➡️</span><span class="eventEmoji">💔</span></div>

          <div class="storyBox">
            You were playing with your favorite toy, but it suddenly broke!
            Now you feel a hot fire in your tummy. You are ANGRY.
          </div>

          <div class="btnRow">
            <button class="btn" id="backFromTrigger" type="button">Back</button>
            <button class="btn btnPrimary" id="nextToReactions" type="button">Next</button>
          </div>
        </div>
      </div>
    `;
  }

  function viewReactionPick() {
    const items = reactions.map(r => `
      <button class="pick" data-reaction="${r.key}" type="button"><span class="pickEmoji">${r.emoji}</span><span class="pickText">${r.title}</span></button>
    `).join("");

    return `
      <div class="screen">
        <div class="panel">
          <p class="cardTitle">What might you do?</p>
          <p class="cardSub">Pick a reaction.</p>

          <div class="grid2">${items}</div>

          <div class="btnRow">
            <button class="btn" id="backFromPick" type="button">Back</button>
          </div>
        </div>
      </div>
    `;
  }

  function viewReactionResult() {
    const r = reactions.find(x => x.key === state.reactionKey);
    return `
      <div class="screen">
        <div class="panel">
          <p class="cardTitle">${r.title}</p>
          <p class="cardSub">This is a negative reaction.</p>

          <div class="eventRow eventRowSmall"><span class="eventEmoji">🧍</span><span class="eventArrow">➡️</span><span class="eventEmoji">${r.emoji}</span></div>

          <div class="storyBox">${r.note}</div>

          <div class="btnRow">
            <button class="btn" id="tryAnother" type="button">Try another reaction</button>
            <button class="btn btnPrimary" id="goTools" type="button">Go to coping tools</button>
          </div>
        </div>
      </div>
    `;
  }

  function viewTools() {
    const toolCards = tools.map(t => `
      <button class="pick" data-tool="${t.key}" type="button"><span class="pickEmoji">${t.emoji}</span><span class="pickText">${t.title}</span></button>
    `).join("");

    return `
      <div class="screen">
        <div class="panel">
          <p class="cardTitle">Coping Tools</p>
          <p class="cardSub">Pick one to calm your body.</p>

          <div class="grid2">${toolCards}</div>

          <div class="btnRow">
            <button class="btn" id="backFromTools" type="button">Back</button>
          </div>
        </div>
      </div>
    `;
  }

  function viewToolSteps() {
    const tool = tools.find(t => t.key === state.toolKey);
    const step = tool.steps[state.toolStep];

    return `
      <div class="screen">
        <div class="panel">
          <p class="cardTitle">${tool.title}</p>
          <p class="cardSub">A calming tool you can practice.</p>

          <div class="btnRow" style="margin-top:6px">
            <span class="toolEmoji">${tool.emoji}</span>
          </div>

          <div class="badge">Step ${state.toolStep + 1} of ${tool.steps.length}</div>

          <div class="storyBox">${step}</div>

          <div class="btnRow">
            <button class="btn" id="restartTool" type="button">Restart</button>
            ${state.toolStep < tool.steps.length - 1
              ? `<button class="btn btnPrimary" id="nextStep" type="button">Next step</button>`
              : `<button class="btn btnPrimary" id="finishTool" type="button">Finish</button>`
            }
          </div>
        </div>
      </div>
    `;
  }

  // ---------- Render + bind ----------
  function render() {
    let html = "";
    switch (state.view) {
      case "welcome":
        html = viewWelcome(); break;
      case "character":
        html = viewCharacter(); break;
      case "trigger":
        html = viewTrigger(); break;
      case "reaction_pick":
        html = viewReactionPick(); break;
      case "reaction_result":
        html = viewReactionResult(); break;
      case "tools":
        html = viewTools(); break;
      case "tool_steps":
        html = viewToolSteps(); break;
      default:
        html = viewWelcome();
    }

    app.innerHTML = html;

    // View bindings
    if (state.view === "welcome") {
      document.getElementById("startBtn").onclick = () => setView("character");
    }

    if (state.view === "character") {
      document.getElementById("pickBoy").onclick = () => { state.character = "boy"; setView("trigger"); };
      document.getElementById("pickGirl").onclick = () => { state.character = "girl"; setView("trigger"); };
      document.getElementById("backFromCharacter").onclick = back;
    }

    if (state.view === "trigger") {
      document.getElementById("backFromTrigger").onclick = back;
      document.getElementById("nextToReactions").onclick = () => setView("reaction_pick");
    }

    if (state.view === "reaction_pick") {
      document.querySelectorAll("[data-reaction]").forEach(btn => {
        btn.onclick = () => {
          state.reactionKey = btn.getAttribute("data-reaction");
          setView("reaction_result");
        };
      });
      document.getElementById("backFromPick").onclick = back;
    }

    if (state.view === "reaction_result") {
      document.getElementById("tryAnother").onclick = () => setView("reaction_pick");
      document.getElementById("goTools").onclick = () => setView("tools");
    }

    if (state.view === "tools") {
      document.querySelectorAll("[data-tool]").forEach(btn => {
        btn.onclick = () => {
          state.toolKey = btn.getAttribute("data-tool");
          state.toolStep = 0;
          setView("tool_steps");
        };
      });
      document.getElementById("backFromTools").onclick = back;
    }

    if (state.view === "tool_steps") {
      document.getElementById("restartTool").onclick = () => { state.toolStep = 0; render(); };

      const nextBtn = document.getElementById("nextStep");
      if (nextBtn) nextBtn.onclick = () => { state.toolStep += 1; render(); };

      const finishBtn = document.getElementById("finishTool");
      if (finishBtn) finishBtn.onclick = () => goTo("/goodbye.html");
    }
  }

  // ---------- Topbar bindings ----------
  btnBack.onclick = back;
  btnHome.onclick = () => goTo("/index.html");
  btnExit.onclick = () => goTo("/goodbye.html");

  btnMusic.onclick = () => {
    musicOn = !musicOn;
    btnMusic.textContent = musicOn ? "Music: On" : "Music";
    if (!bgMusic || !bgMusic.querySelector("source")) return; // no file yet
    if (musicOn) bgMusic.play().catch(() => {});
    else bgMusic.pause();
  };

  // Start
  render();
})();

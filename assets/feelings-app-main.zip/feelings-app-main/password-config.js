// Brave Feelings Lab — Password Config
// Update only the hash value below (SHA-256 hex).

window.BFL_EXPECTED_HASH = "b8a137cb2c0a7f90827dc03b78395624d32d7dc701b6e094a8bc5d8940723752";
window.BFL_SESSION_HOURS = 12;
